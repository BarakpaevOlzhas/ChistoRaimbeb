var express = require("express");
var WebSocketServer = new require('ws');

var exp = express();
exp.set('view engine', 'ejs');
exp.use('/public',express.static('public'));

var webSocketServer = new WebSocketServer.Server({
  port: 8081
});

webSocketServer.on('connection', ws => {
  ws.on('message', message => {
    console.log(`Received message => ${message}`)
    webSocketServer.clients.forEach(client => {
      if(client.readyState == WebSocketServer.OPEN){
        client.send(message);
      }
    });
  })
})





exp.get("/",function(req,res){
  res.render("index");
});

exp.listen(3000);
